//package ItP.ExpressionCalculatorSerializer;
//
//import java.util.Collection;
//import java.util.Iterator;
//import java.util.PriorityQueue;
//import java.util.Queue;
//
//enum Type {
//    STACK("stack"),
//    QUEUE("queue");
//
//    private final String text;
//
//    Type(final String text) {this.text = text;}
//
//    @Override
//    public String toString() {return text;}
//}