//package ItP.ExpressionCalculatorSerializer;
//
//class Node<T> {
//    Node<T> prev;
//    Node<T> next;
//    T value;
//}