package main.java;

import main.java.entities.User;

public class Authentication {

    public static boolean register(String params) {
        return false;
    }

    public static boolean login(User user) {
        return false;
    }

    public static boolean logout(User user) {
        return false;
    }

}
