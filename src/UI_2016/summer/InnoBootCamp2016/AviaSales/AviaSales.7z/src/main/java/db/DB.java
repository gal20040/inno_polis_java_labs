package main.java.db;

public class DB {

    public boolean registerUser(String params) {
        return false;
    }

    public boolean addFlight(String params) {
        return false;
    }

}
