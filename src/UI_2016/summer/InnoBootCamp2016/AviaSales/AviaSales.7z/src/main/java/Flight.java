import java.util.Date;

public class Flight {

    String flightName;
    String departure;
    String arrival;
    Date departureDateTime;
    Date arrivalDateTime;
    Object cost;
    int freePlaces;

    Object distance; //the distance between the point of departure and destination
    Object tripClass; /*Flight class: 0 � econom, 1 � business, 2 � first.*/
    Object numberOfChanges; //the number of transfers
    
//    ArrayList<User> pasengers;
    
//    public ArrayList<Flight> searchFlight(String params) {
//        return null;
//    }

    public Flight() {
    }
    
    public Flight(String departure, String arrival, Date departureDateTime) {
    	this.departure = departure;
    	this.arrival = arrival;
    	this.departureDateTime = departureDateTime;
    }
    
    public Flight(String flightName, String departure, String arrival,
    		Date departureDateTime, Date arrivalDateTime,
    		Object cost, /*int freePlaces, */Object distance, Object tripClass , Object numberOfChanges) {
    	this.flightName = flightName;
        this.departure = departure;
        this.arrival = arrival;
        this.departureDateTime = departureDateTime;
        this.arrivalDateTime = arrivalDateTime;
        this.cost = cost;
//        this.freePlaces = freePlaces; //TODO API ���� ��� �� ����� ���-�� ��������� �������
        this.distance = distance;
        this.tripClass = tripClass;
        this.numberOfChanges = numberOfChanges;
    }
}